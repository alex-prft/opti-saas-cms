// Auto generated dictionary
import { ComponentTypeDictionary } from "@remkoj/optimizely-cms-react";
import ArticleListElement from "./ArticleListElement";

export const elementDictionary : ComponentTypeDictionary = [
    {
        type: 'ArticleListElement',
        component: ArticleListElement
    },
]

export default elementDictionary