// Auto generated dictionary
import { ComponentTypeDictionary } from "@remkoj/optimizely-cms-react";
import BlankExperience from "./BlankExperience";

export const experienceDictionary : ComponentTypeDictionary = [
    {
        type: 'BlankExperience',
        component: BlankExperience
    },
]

export default experienceDictionary